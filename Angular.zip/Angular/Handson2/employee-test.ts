import { Department } from "./department";
import { Employee } from "./employee";
import { Skill } from "./skill";

let skill1 : Skill = {

    skillId : 1,
    skillName : 'HTML'  

}

let skill2 : Skill = {

    skillId : 1,
    skillName : 'CSS'  

}

let skill3 : Skill = {

    skillId : 1,
    skillName : 'JavaScript'  

}

let skills : Skill[] = [skill1, skill2, skill3];

let employee : Employee = {
    id : 3, 
    name : 'John',
    salary :   10000,
    permanent : true,
    department : dept,
    skill : skills
}

class EmployeeTest implements Employee{
    id: number;
    name: string;
    salary: number;
    permanent: boolean;
    deptId: number;
    deptName: string;
    skill : skill
 
   
    constructor(id:number,name: string,salary: number, permanent: boolean,deptId: number,deptName:string){
        this.id=id;
        this.name=name;
        this.salary=salary;
        this.permanent=permanent;
        this.deptId=deptId;
        this.deptName=deptName;
    }
    
   
    

}

let empTest = new EmployeeTest(3,"Abcd",50000,true,1,"Sales");
console.log("Id : " + empTest.id);
console.log("Name : " + empTest.name);
console.log("Salary : " + empTest.salary);
console.log("Permanent : " + empTest.permanent);
console.log("Department Id : " + empTest.deptId);
console.log("Department Name : " + empTest.deptName);