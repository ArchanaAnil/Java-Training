"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EmployeeTest = /** @class */ (function () {
    function EmployeeTest(id, name, salary, permanent, deptId, deptName) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.permanent = permanent;
        this.deptId = deptId;
        this.deptName = deptName;
    }
    return EmployeeTest;
}());
var empTest = new EmployeeTest(3, "Abcd", 50000, true, 1, "Sales");
console.log("Id : " + empTest.id);
console.log("Name : " + empTest.name);
console.log("Salary : " + empTest.salary);
console.log("Permanent : " + empTest.permanent);
console.log("Department Id : " + empTest.deptId);
console.log("Department Name : " + empTest.deptName);
