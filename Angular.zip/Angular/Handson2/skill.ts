export interface Skill { 
    skillId:number,
    skillName:string;
}