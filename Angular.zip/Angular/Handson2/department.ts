export interface Department { 
    deptId:number,
    deptName:string;
}