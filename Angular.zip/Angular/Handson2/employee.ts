import { Department } from "./department";
import { Skill } from "./skill";

export interface Employee extends Department,Skill{ 
    id:number,
    name:string, 
    salary:number,
    permanent: boolean,
    skill : Skill[]

    
 } 