import{Employee} from "./employee";
import {Department} from './department';
import {Skill} from './skill';

let dept : Department = {

    id : 1,
    name : 'Payroll'

}

let skill1 : Skill = {

    id : 1,
    name : 'HTML'  

}

let skill2 : Skill = {

    id : 1,
    name : 'CSS'  

}

let skill3 : Skill = {

    id : 1,
    name : 'JavaScript'  

}

let skills : Skill[] = [skill1, skill2, skill3];

let employee : Employee = {
    id : 3, 
    name : 'John',
    salary :   10000,
    permanent : true,
    department : dept,
    skill : skills
}

console.log("Using interface")
console.log("id: " + employee.id);
console.log("name: " + employee.name);
console.log("salary: " + employee.salary);
console.log("department id: " + employee.department.id);
console.log("department name: " + employee.department.name);
for(let i = 0; i < skills.length; i++){

    console.log("skill[" + i + "]: " + (i + 1) + ", " + skills[i].name);

}

console.log("-----------------------------------")

class EmployeeTest{

    employee : Employee;

    constructor(employee : Employee){

        this.employee = employee;

    }

    display(){

        console.log("Using class")
        console.log("id: " + this.employee.id);
        console.log("name: " + this.employee.name);
        console.log("salary: " + this.employee.salary);
        console.log("department id: " + this.employee.department.id);
        console.log("department name: " + this.employee.department.name);
        for(let i = 0; i < this.employee.skill.length; i++){

            console.log("skill[" + i + "]: " + (i + 1) + ", " + this.employee.skill[i].name);

        }

    }

}

let employeeClass = new EmployeeTest(employee);
employeeClass.display();

