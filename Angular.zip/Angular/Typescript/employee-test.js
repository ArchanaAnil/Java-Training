"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var dept = {
    id: 1,
    name: 'Payroll'
};
var skill1 = {
    id: 1,
    name: 'HTML'
};
var skill2 = {
    id: 1,
    name: 'CSS'
};
var skill3 = {
    id: 1,
    name: 'JavaScript'
};
var skills = [skill1, skill2, skill3];
var employee = {
    id: 3,
    name: 'John',
    salary: 10000,
    permanent: true,
    department: dept,
    skill: skills
};
console.log("Using interface");
console.log("id: " + employee.id);
console.log("name: " + employee.name);
console.log("salary: " + employee.salary);
console.log("department id: " + employee.department.id);
console.log("department name: " + employee.department.name);
for (var i = 0; i < skills.length; i++) {
    console.log("skill[" + i + "]: " + (i + 1) + ", " + skills[i].name);
}
console.log("-----------------------------------");
var EmployeeTest = /** @class */ (function () {
    function EmployeeTest(employee) {
        this.employee = employee;
    }
    EmployeeTest.prototype.display = function () {
        console.log("Using class");
        console.log("id: " + this.employee.id);
        console.log("name: " + this.employee.name);
        console.log("salary: " + this.employee.salary);
        console.log("department id: " + this.employee.department.id);
        console.log("department name: " + this.employee.department.name);
        for (var i = 0; i < this.employee.skill.length; i++) {
            console.log("skill[" + i + "]: " + (i + 1) + ", " + this.employee.skill[i].name);
        }
    };
    return EmployeeTest;
}());
var employeeClass = new EmployeeTest(employee);
employeeClass.display();
