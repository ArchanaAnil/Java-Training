var employeeString = `{

    "firstName" : "John",
    "lastName" : "Stoke",
    "salary" : 5000,
    "permanent" : true,
    "department" :{"id" : 3, "name" : "Payroll"},
    "skills" : [{"id" : 1, "value": "HTML"}, {"id" : 2, "value": "CSS"}, {"id" : 3, "value" : "JavaScript"}]

}`;
var json = JSON.parse(employeeString);
console.log("First Name: " + json.firstName);
console.log("Last Name: " + json.lastName);
console.log("Salary: " + json.salary);
console.log("Permanent Staff: " + json.permanent);
console.log("Department Id: " + json.department.id)
console.log("Department Name: " + json.department.name)
for(let i = 0; i < json.skills.length; i++){

    console.log("Skill " + (i + 1) + ": " + json.skills[i].id + ", " + json.skills[i].value)

}