let data = require('./emp.json');
console.log("------------------------------------------");
console.log("Using external JSON")
console.log("First Name: " + data.firstName);
console.log("Last Name: " + data.lastName);
console.log("Salary: " + data.salary);
console.log("Permanent Staff: " + data.permanent);
console.log("Department Id: " + data.department.id)
console.log("Department Name: " + data.department.name)
for(let i = 0; i < data.skills.length; i++){

    console.log("Skill " + (i + 1) + ": " + data.skills[i].id + ", " + data.skills[i].value)

}