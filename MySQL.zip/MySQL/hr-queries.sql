use hr;

select * from jobs where min_salary >1000;

select first_name,hire_date from employees 
where year(hire_date) between 2002 and 2005 ;

select e.first_name,e.hire_date from employees e,jobs j
where e.job_id=j.job_id 
and j.job_title in ('Programmer','Sales Representative');

select employee_id,manager_id from employees;
select * from jobs;

select * from employees
where hire_date>'2008-01-01'
;

select * from employees
where employee_id in(150,160);

select first_name,salary,commission_pct,hire_date
from employees where salary <10000;

select job_title,(max_salary - min_salary)
from jobs where max_salary between 10000 and 20000;

select first_name,salary,round(salary,-3)
from employees;

select * from jobs
order by job_title;

select first_name,last_name from employees
where last_name like 's%' or first_name like 's%' ;

-- 11
select first_name from employees 
where month(hire_date)=5;

-- select department_id from employees;
select * from employees 
where commission_pct is null and salary between 5000 and 10000
and department_id=30;

select first_name,DATE_ADD(hire_date,interval 30 day) from employees;

select first_name,TIMESTAMPDIFF(year,hire_date, now() ) from employees;

-- 15
select first_name from employees
where year(hire_date)=2001;

SELECT
CONCAT(UCASE(LEFT(first_name, 1)), LCASE(SUBSTRING(first_name, 2))) as firstname,
CONCAT(UCASE(LEFT(last_name, 1)), LCASE(SUBSTRING(last_name, 2))) as lastname
FROM employees;

SELECT SUBSTRING_INDEX(job_title, ' ', 1) from jobs;

select length(first_name) from employees 
where last_name like '___%r%';

-- 19
select ucase(first_name),lcase(email) from employees
where first_name=email;

select first_name from employees 
where year(curdate())=year(hire_date);

select datediff(sysdate(),'2011-01-01');

-- 22
select count(*) from employees 
where year(hire_date)=year(curdate())
group by month(hire_date) ;

select manager_id,count(*) from employees
group by manager_id;

select employee_id,end_date from job_history;

-- 25
select count(*) from employees where date(hire_date)>15; 

select country_id,count(*) from locations
group by country_id;

select avg(salary),department_id from employees
where commission_pct is not null 
group by department_id;

select j.job_id,count(*),sum(e.salary),(j.max_salary-j.min_salary) as diff_in_salary
from jobs j,employees e where e.job_id=j.job_id
group by e.job_id;

select job_id from employees 
where salary>10000 
group by job_id;

-- 30
select year(hire_date) from employees 
group by hire_date 
having count(year(hire_date))>10 ;

select e.department_id
from departments d,employees e 
group by e.department_id
having count(e.commission_pct is not null)>5;

-- 32
select employee_id from job_history
group by employee_id
having count(employee_id)>1;

-- select * from job_history;

select e.job_id from employees e,job_history j
where datediff(j.end_date,j.start_date)>100
group by e.job_id 
having count(e.job_id)>3 ;

select department_id,year(hire_date) as year,count(*)
from employees 
group by department_id,year(hire_date);

-- 35
select department_id from departments 
where manager_id in
(select manager_id from employees 
group by manager_id
having count(manager_id)>5);

update employees set salary=8000
where employee_id=115 and salary<6000;   

 select * from employees;
-- 60
INSERT INTO employees
VALUES
(208,"John","Samuel","johnsamuel",
8990807452,"1996-02-03","HR-REP",5000.00,0.51,120,50);

DELETE from departments where department_id=20;

update employees set job_id='IT_PROG'
where employee_id=110 and department_id=10 and not job_id='IT%';

insert into departments values(340,'Recruiting',120,1700);
