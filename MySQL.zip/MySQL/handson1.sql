create database customer;
use customer;
create table cust(
name varchar(20),
id long,
place varchar(20),
pincode long,
country varchar(20)
);
insert into cust values("ram",10,"Delhi",110022,"india");
insert into cust values("mohan",12,"Pune",110066,"india");
insert into cust values("ramesh",13,"Kochi",120022,"india");
insert into cust values("abhi",14,"Goa",132122,"india");
insert into cust values("akshay",15,"Pune",110666,"india");
insert into cust values("sita",16,"Delhi",110089,"india");
insert into cust values("priya",17,"Kochi",710066,"india");
insert into cust values("payal",18,"Goa",310029,"india");
insert into cust values("tony",19,"Kolkata",770022,"india");
select * from cust;
select * from cust order by name;
select name from cust where place="pune" order by name;
UPDATE cust
SET pincode=719900
WHERE name="priya";
ALTER TABLE cust
ADD email varchar(255);
UPDATE cust
SET pincode=719900
WHERE name='priya';
select * from cust where id between 14 and 16;
select concat('Ms. ',name) as fullname from cust 
where id >15 and id<19;
select concat('Mr. ',name) as fullname from cust 
where id <= 15;
select concat('Mr. ',name) as fullname from cust 
where id = 19;

create user 'john' identified by "john";
grant select on cust to 'john';
create table courses(
course_id int not null primary key,
course_name varchar(30) unique not null, 
rollnum int check (rollnum between 10 and 100)
);
select * from courses;
drop table courses;
select * from cust where name like 'p%';
select * from cust where id in(12,13,16);
select * from cust where email is not null;
select * from cust where name not like 'p%';
select name from cust where id!=10;
update cust set email='kumarakshay@gmail.com' where name='akshay' ;




