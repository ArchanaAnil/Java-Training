 CREATE DATABASE truyum;
 use truyum;
 
 CREATE TABLE user (
    us_id int NOT NULL,
    us_name varchar(60) NOT NULL,
    PRIMARY KEY (us_id)
    );
 
 CREATE TABLE cart (
    ct_id int NOT NULL,
    us_id int,
    me_id int,
    PRIMARY KEY (ct_id),
    CONSTRAINT ct_us_id FOREIGN KEY (us_id) REFERENCES user(us_id),
    CONSTRAINT ct_pr_id FOREIGN KEY (me_id) REFERENCES menu_item(me_id)  
);
ALTER TABLE cart RENAME COLUMN us_id TO ct_us_id;
ALTER TABLE cart RENAME COLUMN me_id TO ct_pr_id;

CREATE TABLE menu_item (
    me_id int NOT NULL,
    me_name varchar(100) NOT NULL,
    me_price numeric(8,2),
    me_active varchar(3),
    me_date_of_launch DATE,
    me_category varchar(45),
    me_free_delivery varchar(3),
    PRIMARY KEY (me_id)
    );
    
    insert into user values (001,"Admin");
    insert into user values (002,"user1");
     insert into user values (003,"user2");
    select * from user;
    
    insert into menu_item 
    values (01,"Burger",129.00,"yes",'2009-09-24','maincourse','yes');
    insert into menu_item 
    values (02,"Sandwich",99.00,"yes",'2009-05-24','maincourse','no');
    insert into menu_item 
    values (03,"Chocolate Shake",79.00,"yes",'2019-09-24','Shakes','no');
    insert into menu_item 
    values (04,"Soup",105.00,"no",'2022-09-01','Starters','no');
     select * from menu_item;
     
     insert into cart values
     (001,002,02);
      insert into cart values
     (002,002,03);
      insert into cart values
     (003,002,04);
     -- insert into cart values
    -- (002,003,03);
    delete from cart where ct_id=002;
    select * from cart;
     
    select * from menu_item 
    where me_active="yes" and me_date_of_launch<CURDATE();
    
    select * from menu_item 
    where me_id=02 or me_id=03;
    
    UPDATE menu_item
    SET me_name = 'Veg Sandwich', me_price = '75.50',me_active = 'no',me_date_of_launch = '2010-11-26',me_category = 'maincourse',me_free_delivery = 'yes'
    WHERE me_id = 02;
    
    select * from menu_item m, cart c
    where c.ct_pr_id=m.me_id and c.ct_us_id=02;
    
     select sum(m.me_price) as total_price from menu_item m, cart c
    where c.ct_pr_id=m.me_id and c.ct_us_id=02;
    
    delete from cart 
    where ct_us_id=02 and ct_pr_id=03;
    