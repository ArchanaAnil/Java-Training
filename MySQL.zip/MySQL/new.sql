create database school;
use school;
create table student(
name varchar(20),
rollnum long,
city varchar(20)
);

insert into student values("ram",10,"Delhi");
insert into student values("ramesh",11,"Delhi");
select * from student;
select name,city from student;
select * from student
where city="Delhi"
and (rollnum=10
or rollnum=11)
;