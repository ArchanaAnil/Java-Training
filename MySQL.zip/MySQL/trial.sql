insert into student values("Anu",14,"Mumbau");
insert into student values("Zayn",15,"Goa");
select * from student;
delete from student  WHERE name="ram";
select * from student ORDER BY name;
use school;
create table student1(
name varchar(20),
rollnum long not null,
city varchar(20),
PRIMARY KEY (rollnum)
);

ALTER TABLE student
ADD constraint student_pk primary key (name);

desc student;
